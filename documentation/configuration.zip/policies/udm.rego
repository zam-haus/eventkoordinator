package udm

import rego.v1

import data.udm.transitions
import data.udm.reviews
import data.udm.validation_rules
import data.udm.proposals


# ─── Imports from other policy modules ─────────────────────────────────────────────
allow if transitions.allow
allow if proposals.allow

success_messages contains msg if some msg in transitions.success_messages
error_messages contains msg if some msg in transitions.error_messages

success_messages contains msg if some msg in reviews.success_messages
error_messages contains msg if some msg in reviews.error_messages

success_messages contains msg if some msg in validation_rules.success_messages
error_messages contains msg if some msg in validation_rules.error_messages
